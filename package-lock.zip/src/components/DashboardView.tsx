import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CalendarDays,
  TrendingUp,
  RotateCcw,
  ClipboardList,
  Activity,
  CheckSquare,
  CreditCard,
  Clock,
  Building2,
  X,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { DashboardCard } from './DashboardCard';
import { Subscription, SubscriptionStatus } from '../types';

interface DashboardViewProps {
  subscriptions: Subscription[];
  counts: any; // Fallback counts from parent
  statusData: any[]; // Fallback data from parent
  COLORS: string[];
}

export const DashboardView: React.FC<DashboardViewProps> = ({ subscriptions, COLORS }) => {
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [showDatePicker, setShowDatePicker] = useState(false);

  const isExpiringSoon = (endDate?: string) => {
    if (!endDate) return false;
    const end = new Date(endDate);
    const now = new Date();
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7;
  };

  const filteredSubscriptions = useMemo(() => {
    if (!dateRange.start && !dateRange.end) return subscriptions;

    return subscriptions.filter(sub => {
      const createdDate = new Date(sub.createdAt);
      if (isNaN(createdDate.getTime())) return true;

      const start = dateRange.start ? new Date(dateRange.start) : new Date(0);
      const end = dateRange.end ? new Date(dateRange.end) : new Date();

      // Normalize start/end for day-only comparison
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);

      return createdDate >= start && createdDate <= end;
    });
  }, [subscriptions, dateRange]);

  const activeCounts = useMemo(() => ({
    renewals: filteredSubscriptions.filter(s => isExpiringSoon(s.endDate)).length,
    pendingApproval: filteredSubscriptions.filter(s => s.status === SubscriptionStatus.PENDING_APPROVAL).length,
    payments: filteredSubscriptions.filter(s => s.status === SubscriptionStatus.PENDING_PAYMENT).length,
    postCopy: filteredSubscriptions.filter(s => s.status === SubscriptionStatus.PAID).length,
    active: filteredSubscriptions.filter(s => s.status === SubscriptionStatus.ACTIVE).length,
    totalValue: filteredSubscriptions.reduce((acc, s) => acc + s.price, 0),
    renewalValue: filteredSubscriptions.filter(s => isExpiringSoon(s.endDate)).reduce((acc, s) => acc + s.price, 0),
  }), [filteredSubscriptions]);

  const activeStatusData = useMemo(() => {
    const data = Object.values(SubscriptionStatus).map(status => ({
      name: status.replace('_', ' ').toLowerCase(),
      value: filteredSubscriptions.filter(s => s.status === status).length,
    })).filter(d => d.value > 0);
    return data;
  }, [filteredSubscriptions]);

  const clearFilter = () => {
    setDateRange({ start: '', end: '' });
    setShowDatePicker(false);
  };

  const hasFilter = dateRange.start || dateRange.end;

  return (
    <motion.div
      key="dashboard"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="space-y-6"
    >
      {/* Top Bar */}
      <div className="relative bg-white p-4 rounded-2xl border border-indigo-50 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <h2 className="text-xl font-bold text-indigo-900">Dashboard Overview</h2>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowDatePicker(!showDatePicker)}
              className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-sm font-medium transition-all ${hasFilter
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                  : 'bg-zinc-50 border-indigo-100 text-zinc-600 hover:bg-indigo-50'
                }`}
            >
              <CalendarDays className="w-4 h-4" />
              {hasFilter
                ? `${dateRange.start || '...'} to ${dateRange.end || '...'}`
                : 'Pick date range'
              }
              {showDatePicker ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {hasFilter && (
              <button
                onClick={clearFilter}
                className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                title="Clear Filter"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Floating Date Picker Dropdown */}
        <AnimatePresence>
          {showDatePicker && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              className="absolute right-4 top-full mt-2 z-50 bg-white border border-indigo-100 rounded-2xl shadow-xl p-4 flex flex-col gap-4 min-w-[300px]"
            >
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase ml-1">From Date</span>
                  <div className="flex items-center gap-2 bg-zinc-50 border border-indigo-50 rounded-xl px-3 py-2">
                    <input
                      type="date"
                      className="bg-transparent text-sm text-indigo-900 outline-none w-full cursor-pointer"
                      value={dateRange.start}
                      onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase ml-1">To Date</span>
                  <div className="flex items-center gap-2 bg-zinc-50 border border-indigo-50 rounded-xl px-3 py-2">
                    <input
                      type="date"
                      className="bg-transparent text-sm text-indigo-900 outline-none w-full cursor-pointer"
                      value={dateRange.end}
                      onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-indigo-50">
                <button
                  onClick={clearFilter}
                  className="text-xs font-semibold text-rose-500 hover:text-rose-600 transition-colors"
                >
                  Clear All
                </button>
                <button
                  onClick={() => setShowDatePicker(false)}
                  className="px-4 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 transition-all shadow-sm"
                >
                  Done
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Row 1: Primary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard
          title="Total Values"
          value={`₹${activeCounts.totalValue.toLocaleString()}`}
          icon={<TrendingUp className="w-5 h-5" />}
          color="text-indigo-600"
          bgColor="bg-indigo-50"
          borderColor="border-indigo-100"
        />
        <DashboardCard
          title="Total Renewal Values"
          value={`₹${activeCounts.renewalValue.toLocaleString()}`}
          icon={<RotateCcw className="w-5 h-5" />}
          color="text-violet-600"
          bgColor="bg-violet-50"
          borderColor="border-violet-100"
        />
        <DashboardCard
          title="Total Subscriptions"
          value={filteredSubscriptions.length}
          icon={<ClipboardList className="w-5 h-5" />}
          color="text-rose-600"
          bgColor="bg-rose-50"
          borderColor="border-rose-100"
        />
        <DashboardCard
          title="Active Subscriptions"
          value={activeCounts.active}
          icon={<Activity className="w-5 h-5" />}
          color="text-emerald-600"
          bgColor="bg-emerald-50"
          borderColor="border-emerald-100"
        />
      </div>

      {/* Row 2: Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard
          title="Pending Approvals"
          value={activeCounts.pendingApproval}
          subtitle={`${activeCounts.pendingApproval} Subscriptions`}
          icon={<CheckSquare className="w-5 h-5" />}
          color="text-amber-600"
          bgColor="bg-amber-50"
          borderColor="border-amber-100"
          layout="horizontal"
        />
        <DashboardCard
          title="Pending Payments"
          value={activeCounts.payments}
          subtitle={`${activeCounts.payments} Subscriptions`}
          icon={<CreditCard className="w-5 h-5" />}
          color="text-emerald-600"
          bgColor="bg-emerald-50"
          borderColor="border-emerald-100"
          layout="horizontal"
        />
        <DashboardCard
          title="Pending Renewals"
          value={activeCounts.renewals}
          subtitle={`${activeCounts.renewals} Subscriptions`}
          icon={<Clock className="w-5 h-5" />}
          color="text-cyan-600"
          bgColor="bg-cyan-50"
          borderColor="border-cyan-100"
          layout="horizontal"
        />
      </div>

      {/* Row 3: Charts and Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6 min-h-[400px] flex flex-col">
          <h3 className="font-bold text-indigo-900 mb-6 flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Subscription Status
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={activeStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {activeStatusData.map((_entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-6 min-h-[400px] flex flex-col">
          <h3 className="font-bold text-indigo-900 mb-6 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Subscriptions Costs
            </span>
            <span className="text-xs text-zinc-400 font-normal">Price</span>
          </h3>
          <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
            {filteredSubscriptions.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-zinc-400">
                <ClipboardList className="w-12 h-12 opacity-20 mb-2" />
                <p className="text-sm">No subscriptions in this range</p>
              </div>
            ) : (
              [...filteredSubscriptions].sort((a, b) => b.price - a.price).map(sub => (
                <div key={sub.id} className="flex items-center justify-between p-3 bg-zinc-50 rounded-xl border border-indigo-50 hover:border-indigo-200 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-indigo-100 group-hover:scale-110 transition-transform">
                      <Building2 className="w-4 h-4 text-indigo-600" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-zinc-900">{sub.subscriptionName}</p>
                      <p className="text-[10px] text-zinc-400 uppercase tracking-wider">{sub.subscriptionNo}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-indigo-600">₹{sub.price.toLocaleString()}</p>
                    <p className="text-[10px] text-zinc-400 uppercase">{sub.frequency}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
