import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { RotateCcw, Search, ArrowUpDown, RefreshCw, MoreHorizontal, Link, X, ExternalLink } from 'lucide-react';
import { Subscription, SubscriptionStatus, UserRole } from '../types';

interface RenewalsViewProps {
  subscriptions: Subscription[];
  updateStatus: (id: string, status: SubscriptionStatus) => void;
  userRole: UserRole;
  onNavigateToNew: () => void;
}

export const RenewalsView: React.FC<RenewalsViewProps> = ({
  subscriptions,
  updateStatus,
  userRole,
  onNavigateToNew
}) => {
  const [view, setView] = React.useState<'pending' | 'history'>('pending');
  const [localSearch, setLocalSearch] = React.useState('');
  const [paymentModal, setPaymentModal] = React.useState<{ open: boolean; subId: string; subName: string; url: string }>({
    open: false, subId: '', subName: '', url: ''
  });

  const isExpiringOrExpired = (endDate?: string) => {
    if (!endDate) return false;
    const end = new Date(endDate);
    const now = new Date();
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7;
  };

  const filteredSubs = React.useMemo(() => {
    let filtered = subscriptions.filter(s => {
      if (view === 'pending') {
        // Show ALL expiring subscriptions regardless of their current status
        // so users can see where each one is in the pipeline
        return isExpiringOrExpired(s.endDate);
      } else {
        // History: ACTIVE subscriptions that completed the full cycle (have startDate from Post Copy)
        return s.status === SubscriptionStatus.ACTIVE && !!s.startDate;
      }
    });

    if (localSearch) {
      const q = localSearch.toLowerCase();
      filtered = filtered.filter(s =>
        s.subscriptionName.toLowerCase().includes(q) ||
        s.subscriberName.toLowerCase().includes(q) ||
        s.companyName.toLowerCase().includes(q) ||
        s.subscriptionNo.toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [subscriptions, view, localSearch]);

  const openPaymentModal = (sub: Subscription) => {
    setPaymentModal({ open: true, subId: sub.id, subName: sub.subscriptionName, url: '' });
  };

  const closePaymentModal = () => {
    setPaymentModal({ open: false, subId: '', subName: '', url: '' });
  };

  return (
    <motion.div
      key="renewals-view"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Payment Link Modal */}
      <AnimatePresence>
        {paymentModal.open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
            onClick={closePaymentModal}
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md mx-4"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
                    <Link className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-indigo-900 text-base">Payment Link</h3>
                    <p className="text-xs text-zinc-400">{paymentModal.subName}</p>
                  </div>
                </div>
                <button onClick={closePaymentModal} className="p-1.5 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-600 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-bold text-zinc-500 uppercase">Payment URL</label>
                <input
                  type="url"
                  placeholder="https://pay.example.com/..."
                  value={paymentModal.url}
                  onChange={e => setPaymentModal(prev => ({ ...prev, url: e.target.value }))}
                  className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  autoFocus
                />
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={closePaymentModal}
                    className="flex-1 py-2.5 text-sm font-bold text-zinc-500 border border-zinc-200 rounded-xl hover:bg-zinc-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={!paymentModal.url.trim()}
                    onClick={() => {
                      if (paymentModal.url.trim()) {
                        window.open(paymentModal.url.trim(), '_blank', 'noopener,noreferrer');
                        closePaymentModal();
                      }
                    }}
                    className="flex-1 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-xl transition-all flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" /> Open Link
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center border border-indigo-100">
            <RotateCcw className="text-indigo-600 w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-indigo-900">Renewals</h2>
            <p className="text-zinc-500 text-sm font-medium">Renew subscriptions that have passed end date</p>
          </div>
        </div>
        <button className="p-2 text-zinc-400 hover:text-indigo-600 transition-colors">
          <MoreHorizontal className="w-6 h-6" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex bg-white rounded-xl border border-indigo-100 p-1 shadow-sm">
        <button
          onClick={() => setView('pending')}
          className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${view === 'pending' ? 'bg-white text-indigo-600 border-2 border-indigo-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
        >
          Pending
        </button>
        <button
          onClick={() => setView('history')}
          className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${view === 'history' ? 'bg-white text-indigo-600 border-2 border-indigo-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
        >
          History
        </button>
      </div>

      <div className="card overflow-hidden border-indigo-50 shadow-xl shadow-indigo-50/20">
        {/* Search */}
        <div className="p-4 bg-white border-b border-indigo-50">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-300" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-12 pr-4 py-3 bg-zinc-50/50 border border-indigo-50 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-zinc-300"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-zinc-50/50 border-b border-indigo-50">
                {view === 'pending' ? (
                  <>
                    <th className="table-header py-4 px-4">Actions</th>
                    <th className="table-header py-4 px-4 text-center">Stage</th>
                    <th className="table-header py-4 px-4">Subscription No</th>
                    <th className="table-header py-4 px-4">Company</th>
                    <th className="table-header py-4 px-4">Subscriber</th>
                    <th className="table-header py-4 px-4">Subscription</th>
                    <th className="table-header py-4 px-4">Frequency</th>
                    <th className="table-header py-4 px-4">
                      <div className="flex items-center gap-1">
                        Price <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th className="table-header py-4 px-4">
                      <div className="flex items-center gap-1">
                        End Date <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                  </>
                ) : (
                  <>
                    <th className="table-header py-4 px-4">Subscription No</th>
                    <th className="table-header py-4 px-4">Company</th>
                    <th className="table-header py-4 px-4">Subscriber</th>
                    <th className="table-header py-4 px-4">Subscription</th>
                    <th className="table-header py-4 px-4">Frequency</th>
                    <th className="table-header py-4 px-4">
                      <div className="flex items-center gap-1">
                        Start Date <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th className="table-header py-4 px-4">
                      <div className="flex items-center gap-1">
                        End Date <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th className="table-header py-4 px-4">
                      <div className="flex items-center gap-1">
                        Price <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th className="table-header py-4 px-4 text-center">Status</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-indigo-50/50">
              {filteredSubs.length === 0 ? (
                <tr>
                  <td colSpan={view === 'pending' ? 9 : 9} className="py-24 text-center text-zinc-300 font-medium italic">
                    No {view} renewals found
                  </td>
                </tr>
              ) : (
                filteredSubs.map((sub, idx) => (
                  <tr key={sub.id} className="hover:bg-indigo-50/20 transition-colors group">
                    {view === 'pending' ? (
                      <>
                        <td className="table-cell py-4 px-4 align-middle">
                          <div className="flex items-center gap-2">
                            {/* Only show action buttons if the subscription is ACTIVE (not yet in pipeline) */}
                            {sub.status === SubscriptionStatus.ACTIVE ? (
                              userRole === UserRole.USER ? (
                                // User: Renew → navigate to New Subscription
                                <>
                                  <button
                                    onClick={() => onNavigateToNew()}
                                    className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
                                  >
                                    <RefreshCw className="w-3 h-3" /> Renew
                                  </button>
                                  <button
                                    onClick={() => openPaymentModal(sub)}
                                    className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
                                  >
                                    <Link className="w-3 h-3" /> Payment Link
                                  </button>
                                </>
                              ) : (
                                // Admin: Renew → back to Pending Approval flow
                                <button
                                  onClick={() => updateStatus(sub.id, SubscriptionStatus.PENDING_APPROVAL)}
                                  className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
                                >
                                  <RefreshCw className="w-3 h-3" /> Renew
                                </button>
                              )
                            ) : (
                              // Already in pipeline — no action needed
                              <span className="text-xs text-zinc-400 italic">In pipeline</span>
                            )}
                          </div>
                        </td>
                        {/* Stage / pipeline status badge */}
                        <td className="table-cell py-4 px-4 align-middle text-center">
                          {(() => {
                            const stageMeta: Record<string, { label: string; cls: string }> = {
                              [SubscriptionStatus.ACTIVE]: { label: 'Needs Renewal', cls: 'border-amber-200 bg-amber-50 text-amber-600' },
                              [SubscriptionStatus.PENDING_APPROVAL]: { label: 'Awaiting Approval', cls: 'border-blue-200 bg-blue-50 text-blue-600' },
                              [SubscriptionStatus.PENDING_PAYMENT]: { label: 'Awaiting Payment', cls: 'border-purple-200 bg-purple-50 text-purple-600' },
                              [SubscriptionStatus.PAID]: { label: 'Post Copy', cls: 'border-indigo-200 bg-indigo-50 text-indigo-600' },
                              [SubscriptionStatus.REJECTED]: { label: 'Rejected', cls: 'border-red-200 bg-red-50 text-red-600' },
                            };
                            const meta = stageMeta[sub.status] ?? { label: sub.status, cls: 'border-zinc-200 bg-zinc-50 text-zinc-500' };
                            return (
                              <span className={`px-3 py-1 rounded-full text-[10px] font-bold border ${meta.cls} whitespace-nowrap`}>
                                {meta.label}
                              </span>
                            );
                          })()}
                        </td>
                        <td className="table-cell py-4 px-4 align-middle font-mono text-xs text-zinc-500">{sub.subscriptionNo}</td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.companyName}</td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.subscriberName}</td>
                        <td className="table-cell py-4 px-4 align-middle">
                          <span className="text-indigo-500 font-bold">{sub.subscriptionName}</span>
                        </td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-500">{sub.frequency}</td>
                        <td className="table-cell py-4 px-4 align-middle font-black text-zinc-900">₹{sub.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-500 text-sm">
                          {sub.endDate ? new Date(sub.endDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="table-cell py-4 px-4 align-middle font-mono text-xs text-zinc-500">{sub.subscriptionNo}</td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.companyName}</td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.subscriberName}</td>
                        <td className="table-cell py-4 px-4 align-middle">
                          <span className="text-indigo-500 font-bold">{sub.subscriptionName}</span>
                        </td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-500">{sub.frequency}</td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-500 text-sm">
                          {sub.startDate ? new Date(sub.startDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                        </td>
                        <td className="table-cell py-4 px-4 align-middle text-zinc-500 text-sm">
                          {sub.endDate ? new Date(sub.endDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                        </td>
                        <td className="table-cell py-4 px-4 align-middle font-black text-zinc-900">₹{sub.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                        <td className="table-cell py-4 px-4 align-middle text-center">
                          <span className="px-4 py-1 rounded-full text-[10px] font-bold border border-emerald-200 bg-emerald-50 text-emerald-600">
                            Active
                          </span>
                        </td>
                      </>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
};
