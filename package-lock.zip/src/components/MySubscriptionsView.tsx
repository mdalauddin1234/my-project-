import React from 'react';
import { motion } from 'motion/react';
import { ClipboardList, Search, ArrowUpDown, Trash2, Image as ImageIcon, RotateCcw } from 'lucide-react';
import { Subscription } from '../types';
import { StatusBadge } from './StatusBadge';

interface MySubscriptionsViewProps {
  subscriptions: Subscription[];
  filteredSubscriptions: Subscription[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  handleSort: (key: keyof Subscription) => void;
  deleteSubscription: (id: string) => void;
}

export const MySubscriptionsView: React.FC<MySubscriptionsViewProps> = ({
  subscriptions,
  filteredSubscriptions,
  searchQuery,
  setSearchQuery,
  handleSort,
  deleteSubscription
}) => {
  return (
    <motion.div 
      key="my-subscriptions"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between bg-white p-6 rounded-2xl border border-indigo-50 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 border border-indigo-100">
            <ClipboardList className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-indigo-900">My Subscriptions</h2>
            <p className="text-sm text-zinc-500">Manage and track all your subscription services</p>
          </div>
        </div>
        <button 
          onClick={() => window.dispatchEvent(new CustomEvent('force-sync'))}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-95"
        >
          <RotateCcw className="w-4 h-4" />
          Sync Now
        </button>
      </div>

      {/* Search and Table Container */}
      <div className="card overflow-hidden">
        <div className="p-4 border-b border-indigo-50 bg-zinc-50/50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input 
              type="text" 
              placeholder="Search..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-indigo-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-zinc-50/80">
                <th className="table-header">Subscription No</th>
                <th className="table-header text-left">Company</th>
                <th className="table-header text-left">Subscriber</th>
                <th className="table-header text-left">Subscription</th>
                <th className="table-header cursor-pointer group" onClick={() => handleSort('price')}>
                  <div className="flex items-center gap-1">
                    Price
                    <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </th>
                <th className="table-header cursor-pointer group" onClick={() => handleSort('endDate')}>
                  <div className="flex items-center gap-1">
                    End Date
                    <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </th>
                <th className="table-header">Status</th>
                <th className="table-header"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-indigo-50">
              {filteredSubscriptions.map((sub, idx) => (
                <tr key={sub.id} className={`${idx % 2 === 0 ? 'bg-white' : 'bg-zinc-50/30'} hover:bg-indigo-50/50 transition-colors group`}>
                  <td className="table-cell font-mono text-xs text-zinc-500">{sub.subscriptionNo}</td>
                  <td className="table-cell font-medium text-zinc-700">{sub.companyName}</td>
                  <td className="table-cell text-zinc-600">{sub.subscriberName}</td>
                  <td className="table-cell">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="text-indigo-600 font-bold hover:underline cursor-pointer">
                          {sub.subscriptionName}
                        </span>
                        {sub.photoUrl && (
                          <div className="w-6 h-6 rounded border border-indigo-100 overflow-hidden group/thumb relative cursor-zoom-in">
                            <img src={sub.photoUrl} alt="Copy" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/thumb:opacity-100 transition-opacity flex items-center justify-center">
                              <ImageIcon className="w-3 h-3 text-white" />
                            </div>
                          </div>
                        )}
                      </div>
                      <span className="text-[10px] text-zinc-400 line-clamp-1 max-w-[200px]" title={sub.details}>
                        {sub.details}
                      </span>
                    </div>
                  </td>
                  <td className="table-cell font-bold text-zinc-900">₹{sub.price.toLocaleString()}</td>
                  <td className="table-cell text-zinc-500 text-xs">
                    {sub.endDate ? new Date(sub.endDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Not yet decided'}
                  </td>
                  <td className="table-cell">
                    <StatusBadge status={sub.status} />
                  </td>
                  <td className="table-cell text-right">
                    <button 
                      onClick={() => deleteSubscription(sub.id)}
                      className="p-2 text-zinc-300 hover:text-rose-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredSubscriptions.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-zinc-400 text-sm">
                    No subscriptions found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
};
