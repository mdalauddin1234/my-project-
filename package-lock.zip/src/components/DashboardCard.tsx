import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  borderColor: string;
  layout?: 'vertical' | 'horizontal';
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ 
  title, value, subtitle, icon, color, bgColor, borderColor, layout = 'vertical' 
}) => {
  if (layout === 'horizontal') {
    return (
      <div className={`bg-white p-5 rounded-2xl border ${borderColor} shadow-sm hover:shadow-md transition-all`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${bgColor} rounded-xl flex items-center justify-center ${color} border ${borderColor}`}>
            {icon}
          </div>
          <div>
            <p className="text-xs font-bold text-zinc-500 uppercase tracking-wider">{title}</p>
            <h4 className="text-xl font-black text-zinc-900">{value}</h4>
            {subtitle && <p className="text-[10px] text-zinc-400 font-medium mt-0.5">{subtitle}</p>}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white p-6 rounded-2xl border ${borderColor} shadow-sm hover:shadow-md transition-all group`}>
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 ${bgColor} rounded-xl flex items-center justify-center ${color} border ${borderColor} group-hover:scale-110 transition-transform`}>
          {icon}
        </div>
      </div>
      <p className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1">{title}</p>
      <h4 className="text-2xl font-black text-zinc-900">{value}</h4>
      {subtitle && <p className="text-xs text-zinc-400 font-medium mt-1">{subtitle}</p>}
    </div>
  );
};
