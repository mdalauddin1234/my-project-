import React, { useState } from 'react';
import { Frequency } from '../types';

interface SubscriptionFormProps {
  onSubmit: (data: any) => void;
  personNames?: string[];
  companyNames?: string[];
}

const DEFAULT_PERSONS = ['Admin', 'Management', 'IT Department', 'Marketing', 'Sales', 'HR', 'Finance'];
const DEFAULT_COMPANIES = ['Amazon', 'Google', 'Microsoft', 'Adobe', 'Slack', 'Zoom', 'Canva', 'DigitalOcean', 'Cloudflare', 'Other'];

export const SubscriptionForm: React.FC<SubscriptionFormProps> = ({ onSubmit, personNames = [], companyNames = [] }) => {
  const persons = personNames.length > 0 ? personNames : DEFAULT_PERSONS;
  const companies = companyNames.length > 0 ? companyNames : DEFAULT_COMPANIES;

  const [formData, setFormData] = useState({
    subscriberName: persons[0] || '',
    subscriptionName: '',
    details: '',
    price: '',
    frequency: Frequency.MONTHLY,
    companyName: companies[0] || ''
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formattedData = {
      ...formData,
      price: parseFloat(formData.price) || 0
    };

    onSubmit(formattedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1">
          <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Name of Person</label>
          <select
            required
            className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all appearance-none"
            value={formData.subscriberName}
            onChange={e => setFormData({ ...formData, subscriberName: e.target.value })}
          >
            {persons.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div className="space-y-1">
          <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Company Name</label>
          <select
            required
            className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all appearance-none"
            value={formData.companyName}
            onChange={e => setFormData({ ...formData, companyName: e.target.value })}
          >
            {companies.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-1">
        <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Subscription Name</label>
        <input
          required
          type="text"
          className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          placeholder="Cloud Storage Pro"
          value={formData.subscriptionName}
          onChange={e => setFormData({ ...formData, subscriptionName: e.target.value })}
        />
      </div>

      <div className="space-y-1">
        <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Purpose of Subscription</label>
        <textarea
          required
          rows={3}
          className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none"
          placeholder="Describe the subscription purpose..."
          value={formData.details}
          onChange={e => setFormData({ ...formData, details: e.target.value })}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1">
          <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Price (₹)</label>
          <input
            required
            type="text"
            className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            placeholder="999"
            value={formData.price}
            onChange={e => setFormData({ ...formData, price: e.target.value })}
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Frequency</label>
          <select
            className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all appearance-none"
            value={formData.frequency}
            onChange={e => setFormData({ ...formData, frequency: e.target.value as Frequency })}
          >
            {Object.values(Frequency).map(f => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-100 transition-all active:scale-[0.98] mt-4">
        Create Subscription
      </button>
    </form>
  );
};
