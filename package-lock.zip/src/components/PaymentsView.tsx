import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CreditCard, MoreHorizontal, Search, ArrowUpDown, Link, X, ExternalLink } from 'lucide-react';
import { Subscription, SubscriptionStatus } from '../types';

interface PaymentsViewProps {
  subscriptions: Subscription[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  updateStatus: (id: string, status: SubscriptionStatus) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  subscriptions,
  searchQuery,
  setSearchQuery,
  updateStatus
}) => {
  const [view, setView] = React.useState<'pending' | 'history'>('pending');
  const [paymentModal, setPaymentModal] = React.useState<{ open: boolean; subId: string; subName: string; url: string }>({
    open: false, subId: '', subName: '', url: ''
  });

  const DEFAULT_PAYMENT_URL = 'https://docs.google.com/forms/d/e/1FAIpQLScn8tHEUldlOM_8DKpHUfHHiRImDVjkpkhhfduaZUIxpxlJrA/viewform';

  const openPaymentModal = (sub: Subscription) => {
    setPaymentModal({ open: true, subId: sub.id, subName: sub.subscriptionName, url: DEFAULT_PAYMENT_URL });
  };

  const closePaymentModal = () => {
    setPaymentModal({ open: false, subId: '', subName: '', url: '' });
  };

  const filteredSubs = React.useMemo(() => {
    let filtered = subscriptions.filter(s =>
      view === 'pending'
        ? s.status === SubscriptionStatus.PENDING_PAYMENT
        : (s.status === SubscriptionStatus.PAID || s.status === SubscriptionStatus.ACTIVE)
    );

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(s =>
        s.subscriptionName.toLowerCase().includes(q) ||
        s.subscriberName.toLowerCase().includes(q) ||
        s.companyName.toLowerCase().includes(q) ||
        s.subscriptionNo.toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [subscriptions, view, searchQuery]);

  return (
    <motion.div
      key="payments"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="space-y-6"
    >
      {/* Payment Link Modal */}
      <AnimatePresence>
        {paymentModal.open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
            onClick={closePaymentModal}
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md mx-4"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
                    <Link className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-indigo-900 text-base">Payment Link</h3>
                    <p className="text-xs text-zinc-400">{paymentModal.subName}</p>
                  </div>
                </div>
                <button onClick={closePaymentModal} className="p-1.5 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-600 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                <label className="text-xs font-bold text-zinc-500 uppercase">Payment URL</label>
                <input
                  type="url"
                  placeholder="https://pay.example.com/..."
                  value={paymentModal.url}
                  onChange={e => setPaymentModal(prev => ({ ...prev, url: e.target.value }))}
                  className="w-full bg-zinc-50 border border-indigo-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  autoFocus
                />
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={closePaymentModal}
                    className="flex-1 py-2.5 text-sm font-bold text-zinc-500 border border-zinc-200 rounded-xl hover:bg-zinc-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={!paymentModal.url.trim()}
                    onClick={() => {
                      if (paymentModal.url.trim()) {
                        window.open(paymentModal.url.trim(), '_blank', 'noopener,noreferrer');
                        closePaymentModal();
                      }
                    }}
                    className="flex-1 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-xl transition-all flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" /> Open Link
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center border border-indigo-200">
            <CreditCard className="text-indigo-600 w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-indigo-900">Payments</h2>
            <p className="text-zinc-500 text-sm">Manage and process payments for approved subscriptions</p>
          </div>
        </div>
        <button className="p-2 text-zinc-400 hover:text-indigo-600 transition-colors">
          <MoreHorizontal className="w-6 h-6" />
        </button>
      </div>

      <div className="card">
        <div className="flex border-b border-indigo-50">
          <button
            onClick={() => setView('pending')}
            className={`flex-1 py-3 text-sm font-bold transition-all ${view === 'pending' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30' : 'text-zinc-400 hover:text-zinc-600'}`}
          >
            Pending
          </button>
          <button
            onClick={() => setView('history')}
            className={`flex-1 py-3 text-sm font-bold transition-all ${view === 'history' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30' : 'text-zinc-400 hover:text-zinc-600'}`}
          >
            History
          </button>
        </div>

        <div className="p-4 bg-zinc-50/50 border-b border-indigo-50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-indigo-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-zinc-50/50 border-b border-indigo-50">
                <th className="table-header py-4 px-4">{view === 'pending' ? 'Actions' : 'Status'}</th>
                <th className="table-header py-4 px-4">Subscription No</th>
                <th className="table-header py-4 px-4">Company</th>
                <th className="table-header py-4 px-4">Subscriber</th>
                <th className="table-header py-4 px-4">Subscription</th>
                <th className="table-header py-4 px-4">
                  <div className="flex items-center gap-1">
                    Price <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="table-header py-4 px-4">Frequency</th>
                <th className="table-header py-4 px-4">
                  <div className="flex items-center gap-1">
                    Approved On <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-indigo-50/50">
              {filteredSubs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-24 text-center text-zinc-300 font-medium italic">
                    {view === 'pending' ? 'No pending payments found' : 'No payment history found'}
                  </td>
                </tr>
              ) : (
                filteredSubs.map(sub => (
                  <tr key={sub.id} className="hover:bg-indigo-50/20 transition-colors group">
                    <td className="table-cell py-4 px-4 align-middle">
                      {view === 'pending' ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateStatus(sub.id, SubscriptionStatus.PAID)}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 whitespace-nowrap"
                          >
                            Process
                          </button>
                          <button
                            onClick={() => openPaymentModal(sub)}
                            className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <Link className="w-3 h-3" /> Payment Link
                          </button>
                        </div>
                      ) : (
                        <span className={`px-4 py-1.5 rounded-full text-[10px] font-bold border ${sub.status === SubscriptionStatus.PAID ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-emerald-50 text-emerald-600 border-emerald-100'}`}>
                          {sub.status.replace('_', ' ')}
                        </span>
                      )}
                    </td>
                    <td className="table-cell py-4 px-4 align-middle font-mono text-xs text-zinc-500">{sub.subscriptionNo}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-600 font-bold">{sub.companyName}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.subscriberName}</td>
                    <td className="table-cell py-4 px-4 align-middle">
                      <div className="flex flex-col">
                        <span className="text-indigo-600 font-bold">{sub.subscriptionName}</span>
                        <span className="text-[10px] text-zinc-400 line-clamp-1 max-w-[200px]" title={sub.details}>
                          {sub.details}
                        </span>
                      </div>
                    </td>
                    <td className="table-cell py-4 px-4 align-middle font-black text-zinc-900">₹{sub.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-500">{sub.frequency}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-500 text-sm">{sub.approvedOn || '-'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
};
