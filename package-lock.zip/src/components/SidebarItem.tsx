import React from 'react';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
  count?: number;
}

export const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, active, onClick, count }) => (
  <button 
    onClick={onClick}
    className={`sidebar-item w-full ${active ? 'active' : ''}`}
  >
    <div className="flex items-center gap-3">
      {icon}
      <span className="text-sm font-medium">{label}</span>
    </div>
    {count !== undefined && count > 0 && (
      <span className="bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
        {count}
      </span>
    )}
  </button>
);
