import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, XCircle, MonitorCheck, Search, ArrowUpDown, MoreHorizontal, Eye } from 'lucide-react';
import { Subscription, SubscriptionStatus } from '../types';

interface PendingApprovalViewProps {
  subscriptions: Subscription[];
  updateStatus: (id: string, status: SubscriptionStatus) => void;
}

export const PendingApprovalView: React.FC<PendingApprovalViewProps> = ({
  subscriptions,
  updateStatus
}) => {
  const [view, setView] = React.useState<'pending' | 'history'>('pending');
  const [localSearch, setLocalSearch] = React.useState('');
  const [selectedSub, setSelectedSub] = React.useState<Subscription | null>(null);

  const filteredSubs = React.useMemo(() => {
    let filtered = subscriptions.filter(s => 
      view === 'pending' 
        ? s.status === SubscriptionStatus.PENDING_APPROVAL 
        : (s.status !== SubscriptionStatus.PENDING_APPROVAL)
    );

    if (localSearch) {
      const q = localSearch.toLowerCase();
      filtered = filtered.filter(s => 
        s.subscriptionName.toLowerCase().includes(q) || 
        s.subscriberName.toLowerCase().includes(q) || 
        s.companyName.toLowerCase().includes(q) ||
        s.subscriptionNo.toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [subscriptions, view, localSearch]);

  return (
    <motion.div 
      key="pending-approval"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center border border-indigo-100">
            <MonitorCheck className="text-indigo-600 w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-indigo-900">Pending Approval</h2>
            <p className="text-zinc-500 text-sm font-medium">Subscriptions requests pending for approval</p>
          </div>
        </div>
        <button className="p-2 text-zinc-400 hover:text-indigo-600 transition-colors">
          <MoreHorizontal className="w-6 h-6" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex bg-white rounded-xl border border-indigo-100 p-1 shadow-sm">
        <button 
          onClick={() => setView('pending')}
          className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${view === 'pending' ? 'bg-white text-indigo-600 border-2 border-indigo-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
        >
          Pending
        </button>
        <button 
          onClick={() => setView('history')}
          className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${view === 'history' ? 'bg-white text-indigo-600 border-2 border-indigo-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
        >
          History
        </button>
      </div>

      <div className="card overflow-hidden border-indigo-50 shadow-xl shadow-indigo-50/20">
        {/* Search */}
        <div className="p-4 bg-white border-b border-indigo-50">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-300" />
            <input 
              type="text" 
              placeholder="Search..." 
              className="w-full pl-12 pr-4 py-3 bg-zinc-50/50 border border-indigo-50 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-zinc-300"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-zinc-50/50 border-b border-indigo-50">
                <th className="table-header py-4 px-4">Action</th>
                <th className="table-header py-4 px-4">Requested On</th>
                <th className="table-header py-4 px-4">Subscription No</th>
                <th className="table-header py-4 px-4">Company</th>
                <th className="table-header py-4 px-4">Subscriber</th>
                <th className="table-header py-4 px-4">Subscription</th>
                <th className="table-header py-4 px-4">
                  <div className="flex items-center gap-1">
                    Price <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="table-header py-4 px-4">Frequency</th>
                {view === 'history' && <th className="table-header py-4 px-4">Purpose</th>}
                {view === 'history' && <th className="table-header py-4 px-4">Status</th>}
                {view === 'history' && (
                  <th className="table-header py-4 px-4">
                    <div className="flex items-center gap-1">
                      Reviewed On <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-indigo-50/50">
              {filteredSubs.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-24 text-center text-zinc-300 font-medium italic">
                    No {view} requests found
                  </td>
                </tr>
              ) : (
                filteredSubs.map(sub => (
                  <tr key={sub.id} className="hover:bg-indigo-50/20 transition-colors group">
                    <td className="table-cell py-4 px-4 align-middle">
                      {view === 'pending' ? (
                        <button 
                          onClick={() => setSelectedSub(sub)}
                          className="bg-indigo-500 hover:bg-indigo-600 text-white px-6 py-2 rounded-lg text-xs font-bold transition-all active:scale-95"
                        >
                          Review
                        </button>
                      ) : (
                        <div className="w-8 h-8 bg-zinc-100 rounded-lg flex items-center justify-center">
                          <Eye className="w-4 h-4 text-zinc-400" />
                        </div>
                      )}
                    </td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-500 text-xs font-medium">
                      {(() => {
                        const date = new Date(sub.createdAt);
                        return isNaN(date.getTime()) 
                          ? sub.createdAt // Fallback if it's not a valid date (like SUB-0015)
                          : date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
                      })()}
                    </td>
                    <td className="table-cell py-4 px-4 align-middle font-mono text-xs text-zinc-500">{sub.subscriptionNo}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.companyName}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-600">{sub.subscriberName}</td>
                    <td className="table-cell py-4 px-4 align-middle">
                      <span className="text-indigo-500 font-bold">{sub.subscriptionName}</span>
                    </td>
                    <td className="table-cell py-4 px-4 align-middle font-black text-zinc-900">₹{sub.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    <td className="table-cell py-4 px-4 align-middle text-zinc-500">{sub.frequency}</td>
                    {view === 'history' && (
                      <td className="table-cell py-4 px-4 align-middle">
                        <div className="max-w-[150px] truncate text-[11px] text-zinc-500 bg-zinc-100/80 px-3 py-1.5 rounded-lg border border-zinc-200/50" title={sub.details}>
                          {sub.details || '-'}
                        </div>
                      </td>
                    )}
                    {view === 'history' && (
                      <td className="table-cell py-4 px-4 align-middle">
                        <span className={`px-4 py-1.5 rounded-full text-[11px] font-bold border ${
                          sub.status === SubscriptionStatus.PAID || sub.status === SubscriptionStatus.ACTIVE || sub.status === SubscriptionStatus.PENDING_PAYMENT
                            ? 'bg-emerald-50 text-emerald-600 border-emerald-200' 
                            : sub.status === SubscriptionStatus.REJECTED 
                            ? 'bg-rose-50 text-rose-600 border-rose-200' 
                            : 'bg-amber-50 text-amber-600 border-amber-200'
                        }`}>
                          {sub.status === SubscriptionStatus.PENDING_PAYMENT ? 'Approved' : sub.status.replace('_', ' ')}
                        </span>
                      </td>
                    )}
                    {view === 'history' && (
                      <td className="table-cell py-4 px-4 align-middle text-zinc-500 text-sm">
                        {sub.approvedOn || '-'}
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review Modal */}
      {selectedSub && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
          >
            <div className="p-6 border-b border-indigo-50 flex justify-between items-center bg-indigo-50/30">
              <h3 className="text-xl font-bold text-indigo-900">Review Subscription</h3>
              <button onClick={() => setSelectedSub(null)} className="text-zinc-400 hover:text-zinc-600">
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] uppercase font-bold text-zinc-400 mb-1">Subscription Details</p>
                  <h4 className="text-lg font-bold text-zinc-900">{selectedSub.subscriptionName}</h4>
                  <p className="text-sm text-zinc-500">{selectedSub.companyName} • {selectedSub.subscriberName}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-indigo-600">₹{selectedSub.price.toLocaleString()}</p>
                  <p className="text-xs text-zinc-400 font-bold uppercase">{selectedSub.frequency}</p>
                </div>
              </div>

              <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                <p className="text-[10px] uppercase font-bold text-zinc-400 mb-2">Purpose / Description</p>
                <p className="text-sm text-zinc-600 leading-relaxed">{selectedSub.details || 'No details provided'}</p>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => {
                    updateStatus(selectedSub.id, SubscriptionStatus.PENDING_PAYMENT);
                    setSelectedSub(null);
                  }}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-100 active:scale-95"
                >
                  <CheckCircle2 className="w-5 h-5" /> Approve Request
                </button>
                <button 
                  onClick={() => {
                    updateStatus(selectedSub.id, SubscriptionStatus.REJECTED);
                    setSelectedSub(null);
                  }}
                  className="flex-1 bg-rose-50 hover:bg-rose-100 text-rose-600 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <XCircle className="w-5 h-5" /> Reject Request
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
};
