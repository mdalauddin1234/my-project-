export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER'
}

export interface User {
  id: string;
  name: string;
  email: string;
  username: string;
  password?: string;
  role: UserRole;
  lastLogin?: string;
}

export enum SubscriptionStatus {
  PENDING_APPROVAL = 'PENDING_APPROVAL',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  PENDING_PAYMENT = 'PENDING_PAYMENT',
  PAID = 'PAID',
  ACTIVE = 'ACTIVE',
  EXPIRED = 'EXPIRED'
}

export enum Frequency {
  MONTHLY = 'Monthly',
  QUARTERLY = 'Quarterly',
  HALF_YEARLY = 'Half-Yearly',
  YEARLY = 'Yearly'
}

export interface Subscription {
  id: string;
  subscriptionNo: string;
  subscriberName: string;
  subscriptionName: string;
  details: string;
  price: number;
  frequency: Frequency;
  companyName: string;
  status: SubscriptionStatus;
  startDate?: string;
  endDate?: string;
  photoUrl?: string;
  createdAt: string;
  approvedOn?: string;
  timeDelay?: number | string;
  rowIndex?: number; // sheet row position for reliable UPDATE matching
}
