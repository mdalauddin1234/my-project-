/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  LayoutGrid,
  LayoutDashboard,
  PlusSquare,
  ClipboardList,
  RotateCcw,
  CheckSquare,
  CreditCard,
  Users as UserManagementIcon,
  LogOut,
  Search,
  ArrowUpDown,
  MoreHorizontal,
  ChevronRight,
  Calendar,
  Building2,
  User as UserIcon,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  Image as ImageIcon,
  AlertCircle,
  RefreshCw,
  Upload,
  TrendingUp,
  Activity,
  CalendarDays,
  Clock,
  Copy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Subscription, SubscriptionStatus, Frequency, UserRole, User } from './types';

// Components
import { SidebarItem } from './components/SidebarItem';
import { DashboardView } from './components/DashboardView';
import { MySubscriptionsView } from './components/MySubscriptionsView';
import { PaymentsView } from './components/PaymentsView';
import { PendingApprovalView } from './components/PendingApprovalView';
import { RenewalsView } from './components/RenewalsView';
import { PostCopyView } from './components/PostCopyView';
import { UserManagementView } from './components/UserManagementView';
import { SubscriptionForm } from './components/SubscriptionForm';
import { LoginView } from './components/LoginView';

// Services
import {
  fetchFromSheet,
  addSubscriptionToSheet,
  deleteSubscriptionFromSheet,
  updateSubscriptionInSheet,
  addToRenewalDB,
  fetchUsersFromSheet,
  addUserToSheet,
  deleteUserFromSheet
} from './services/googleSheetService';

type TabType = 'dashboard' | 'new' | 'my-subscriptions' | 'renewals' | 'pending-approval' | 'payments' | 'post-copy' | 'user-management';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const lastActionTimeRef = React.useRef(0);

  const handleFetchFromSheet = React.useCallback(async (force = false) => {
    const now = Date.now();
    if (!force && now - lastActionTimeRef.current < 30000) return;

    setIsSyncing(true);
    try {
      const [syncedSubs, syncedUsers] = await Promise.all([
        fetchFromSheet(),
        fetchUsersFromSheet()
      ]);

      if (syncedSubs !== null) setSubscriptions(syncedSubs);

      if (syncedUsers !== null) {
        console.log("Synced users from sheet:", syncedUsers.length);
        const mappedUsers: User[] = syncedUsers.map((u, i) => {
          const getVal = (keys: string[]) => {
            for (const k of keys) {
              const cleanK = k.toLowerCase().replace(/[^a-z0-9]/g, '');
              if (u[cleanK] !== undefined && u[cleanK] !== '') return u[cleanK];
            }
            return '';
          };

          return {
            id: u.id || `user-${i}`,
            name: getVal(['name', 'fullname', 'displayname']) || 'Unknown',
            email: getVal(['email', 'emailid', 'mail']),
            username: getVal(['username', 'user', 'login']),
            password: (getVal(['password', 'pass', 'pwd']) || '').toString(),
            role: (getVal(['role', 'type']) || '').toString().trim().toUpperCase() === 'ADMIN' ? UserRole.ADMIN : UserRole.USER,
            lastLogin: getVal(['lastlogin', 'lastseen']) || ''
          };
        });
        setUsers(mappedUsers);
      }
    } catch (error) {
      console.error("Failed to sync with sheet:", error);
    } finally {
      setIsSyncing(false);
    }
  }, []);

  useEffect(() => {
    const savedUser = localStorage.getItem('subflow_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      if (user.role === UserRole.ADMIN) setActiveTab('dashboard');
      else setActiveTab('new');
    }

    handleFetchFromSheet(true);
  }, [handleFetchFromSheet]);

  useEffect(() => {
    if (currentUser) localStorage.setItem('subflow_user', JSON.stringify(currentUser));
    else localStorage.removeItem('subflow_user');
  }, [currentUser]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    if (user.role === UserRole.ADMIN) setActiveTab('dashboard');
    else setActiveTab('new');
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const addSubscription = async (newSub: Omit<Subscription, 'id' | 'status' | 'createdAt' | 'subscriptionNo'>) => {
    // Find the highest existing SUB number and increment
    const maxNo = subscriptions.reduce((max, s) => {
      const match = s.subscriptionNo.match(/SUB-(\d+)/);
      return match ? Math.max(max, parseInt(match[1], 10)) : max;
    }, 0);
    const nextNo = (maxNo + 1).toString().padStart(4, '0');
    const sub: Subscription = {
      ...newSub,
      id: Math.random().toString(36).substr(2, 9),
      subscriptionNo: `SUB-${nextNo}`,
      status: SubscriptionStatus.PENDING_APPROVAL,
      createdAt: new Date().toISOString(),
    };

    // Optimistically add to UI
    setSubscriptions([sub, ...subscriptions]);
    lastActionTimeRef.current = Date.now();
    setActiveTab('my-subscriptions');

    const success = await addSubscriptionToSheet(sub);
    if (success) {
      console.log("Data sent to Google Sheets successfully.");
    }
  };

  const updateStatus = async (id: string, status: SubscriptionStatus, extraData: Partial<Subscription> = {}) => {
    // Use a functional setState to get the CURRENT (non-stale) subscriptions
    let updatedSub: Subscription | null = null;

    setSubscriptions(subs => {
      const currentSub = subs.find(s => s.id === id);
      if (!currentSub) return subs;

      const updated: Subscription = { ...currentSub, status, ...extraData };
      if (status === SubscriptionStatus.PENDING_PAYMENT && !currentSub.approvedOn) {
        updated.approvedOn = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      }
      updatedSub = updated;
      return subs.map(s => s.id === id ? updated : s);
    });

    lastActionTimeRef.current = Date.now();

    // Sync to Google Sheet
    await new Promise(resolve => setTimeout(resolve, 50));
    if (updatedSub) {
      const success = await updateSubscriptionInSheet(updatedSub);
      if (success) {
        console.log("Status update synced with Google Sheets:", (updatedSub as Subscription).subscriptionNo, "→", status);
      }
      // When a subscription is renewed → also add a row to the Renewal DB sheet
      if (status === SubscriptionStatus.PENDING_APPROVAL) {
        await addToRenewalDB(updatedSub as Subscription);
        console.log("Renewal entry added to Renewal DB:", (updatedSub as Subscription).subscriptionNo);
      }
    }
  };

  const deleteSubscription = async (id: string) => {
    const subToDelete = subscriptions.find(s => s.id === id);
    if (!subToDelete) return;

    if (window.confirm(`Are you sure you want to delete "${subToDelete.subscriptionName}"?`)) {
      // Optimistically remove from UI
      setSubscriptions(subs => subs.filter(s => s.id !== id));

      const success = await deleteSubscriptionFromSheet(subToDelete.subscriptionNo);
      if (success) {
        console.log("Deletion synced with Google Sheets");
      }
    }
  };

  const addUser = async (newUser: Omit<User, 'id'>) => {
    const user: User = {
      ...newUser,
      id: Math.random().toString(36).substr(2, 9),
    };

    setUsers([user, ...users]);
    lastActionTimeRef.current = Date.now();

    const success = await addUserToSheet(user);
    if (success) {
      console.log("User added to Google Sheets successfully.");
    }
  };

  const deleteUser = async (username: string) => {
    const userToDelete = users.find(u => u.username === username);
    if (!userToDelete) return;

    if (window.confirm(`Are you sure you want to delete user "${userToDelete.name}"?`)) {
      setUsers(prev => prev.filter(u => u.username !== username));
      lastActionTimeRef.current = Date.now();

      const success = await deleteUserFromSheet(username);
      if (success) {
        console.log("User deletion synced with Google Sheets");
      }
    }
  };

  const isExpiringSoon = (endDate?: string) => {
    if (!endDate) return false;
    const end = new Date(endDate);
    const now = new Date();
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    // Include expired and expiring soon (within 7 days)
    return diffDays <= 7;
  };

  const counts = useMemo(() => ({
    renewals: subscriptions.filter(s => isExpiringSoon(s.endDate)).length,
    pendingApproval: subscriptions.filter(s => s.status === SubscriptionStatus.PENDING_APPROVAL).length,
    payments: subscriptions.filter(s => s.status === SubscriptionStatus.PENDING_PAYMENT).length,
    postCopy: subscriptions.filter(s => s.status === SubscriptionStatus.PAID).length,
    active: subscriptions.filter(s => s.status === SubscriptionStatus.ACTIVE).length,
    totalValue: subscriptions.reduce((acc, s) => acc + s.price, 0),
    renewalValue: subscriptions.filter(s => isExpiringSoon(s.endDate)).reduce((acc, s) => acc + s.price, 0),
  }), [subscriptions]);

  const statusData = useMemo(() => {
    const data = Object.values(SubscriptionStatus).map(status => ({
      name: status.replace('_', ' ').toLowerCase(),
      value: subscriptions.filter(s => s.status === status).length,
    })).filter(d => d.value > 0);
    return data;
  }, [subscriptions]);

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];

  const [sortConfig, setSortConfig] = useState<{ key: keyof Subscription; direction: 'asc' | 'desc' } | null>(null);

  const handleSort = (key: keyof Subscription) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const filteredSubscriptions = useMemo(() => {
    let filtered = [...subscriptions];
    if (activeTab === 'payments') {
      filtered = subscriptions.filter(s => s.status === SubscriptionStatus.PENDING_PAYMENT);
    } else if (activeTab === 'pending-approval') {
      filtered = subscriptions.filter(s => s.status === SubscriptionStatus.PENDING_APPROVAL);
    } else if (activeTab === 'renewals') {
      filtered = subscriptions.filter(s => isExpiringSoon(s.endDate));
    } else if (activeTab === 'post-copy') {
      filtered = subscriptions.filter(s => s.status === SubscriptionStatus.PAID);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(s =>
        s.subscriptionName.toLowerCase().includes(q) ||
        s.subscriberName.toLowerCase().includes(q) ||
        s.companyName.toLowerCase().includes(q) ||
        s.subscriptionNo.toLowerCase().includes(q)
      );
    }

    if (sortConfig) {
      filtered.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];

        if (aVal === undefined || bVal === undefined) return 0;

        if (aVal < bVal) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aVal > bVal) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return filtered;
  }, [subscriptions, activeTab, searchQuery, sortConfig]);

  if (!currentUser) {
    return <LoginView onLogin={handleLogin} users={users} />;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--color-content-bg)]">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-indigo-100 flex flex-col shrink-0">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
            <LayoutGrid className="text-white w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-lg font-bold text-indigo-900 leading-tight">Subscription</h1>
            <span className="text-sm font-semibold text-indigo-500 leading-tight">Manager</span>
          </div>
          <button
            onClick={() => handleFetchFromSheet(true)}
            disabled={isSyncing}
            className="ml-auto p-1.5 text-zinc-400 hover:text-indigo-600 transition-colors"
            title="Sync Data"
          >
            <RotateCcw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto py-4">
          {currentUser.role === UserRole.ADMIN && (
            <SidebarItem
              icon={<LayoutDashboard className="w-5 h-5" />}
              label="Dashboard"
              active={activeTab === 'dashboard'}
              onClick={() => setActiveTab('dashboard')}
            />
          )}

          <SidebarItem
            icon={<PlusSquare className="w-5 h-5" />}
            label="New Subscription"
            active={activeTab === 'new'}
            onClick={() => setActiveTab('new')}
          />

          <SidebarItem
            icon={<ClipboardList className="w-5 h-5" />}
            label="My Subscriptions"
            active={activeTab === 'my-subscriptions'}
            onClick={() => setActiveTab('my-subscriptions')}
          />

          {currentUser.role === UserRole.ADMIN && (
            <>
              <SidebarItem
                icon={<CheckSquare className="w-5 h-5" />}
                label="Pending Approval"
                count={counts.pendingApproval}
                active={activeTab === 'pending-approval'}
                onClick={() => setActiveTab('pending-approval')}
              />
              <SidebarItem
                icon={<CreditCard className="w-5 h-5" />}
                label="Payments"
                count={counts.payments}
                active={activeTab === 'payments'}
                onClick={() => setActiveTab('payments')}
              />
              <SidebarItem
                icon={<Copy className="w-5 h-5" />}
                label="Post Copy"
                count={counts.postCopy}
                active={activeTab === 'post-copy'}
                onClick={() => setActiveTab('post-copy')}
              />
            </>
          )}

          <SidebarItem
            icon={<RotateCcw className="w-5 h-5" />}
            label="Renewals"
            count={counts.renewals}
            active={activeTab === 'renewals'}
            onClick={() => setActiveTab('renewals')}
          />

          {currentUser.role === UserRole.ADMIN && (
            <SidebarItem
              icon={<UserManagementIcon className="w-5 h-5" />}
              label="User Management"
              active={activeTab === 'user-management'}
              onClick={() => setActiveTab('user-management')}
            />
          )}
        </nav>

        <div className="p-4 border-t border-indigo-50 space-y-4">
          <div className="flex items-center gap-3 px-2">
            <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center border border-indigo-100">
              <span className="text-indigo-600 font-bold text-lg">{currentUser.name[0]}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-zinc-400">Name: <span className="text-zinc-700 font-semibold">{currentUser.name}</span></span>
              <span className="text-xs text-zinc-400">Username: <span className="text-zinc-700 font-semibold">{currentUser.username}</span></span>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-white border border-indigo-100 rounded-xl text-zinc-600 hover:bg-indigo-50 hover:text-indigo-600 transition-all font-medium text-sm shadow-sm"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
          <div className="text-center">
            <p className="text-[10px] text-zinc-400">Powered by - <span className="text-indigo-400 font-medium">Botivate</span></p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8 custom-scrollbar">
        {/* Renewal Reminder Banner */}
        {counts.renewals > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
                <AlertCircle className="text-amber-600 w-6 h-6" />
              </div>
              <div>
                <h4 className="text-amber-900 font-bold">Renewal Reminder</h4>
                <p className="text-amber-700 text-sm">You have {counts.renewals} subscriptions expiring within 7 days.</p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('renewals')}
              className="bg-amber-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-lg shadow-amber-100"
            >
              View Renewals
            </button>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && currentUser.role === UserRole.ADMIN && (
            <DashboardView
              subscriptions={subscriptions}
              counts={counts}
              statusData={statusData}
              COLORS={COLORS}
            />
          )}

          {activeTab === 'new' && (
            <motion.div
              key="new"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-2xl mx-auto"
            >
              <div className="card p-8">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
                    <Plus className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-indigo-900">New Subscription</h2>
                    <p className="text-zinc-500">Add a new service to your tracking list</p>
                  </div>
                </div>
                <SubscriptionForm
                  onSubmit={addSubscription}
                  personNames={[...new Set(subscriptions.map(s => s.subscriberName).filter(Boolean))]}
                  companyNames={[...new Set(subscriptions.map(s => s.companyName).filter(Boolean))]}
                />
              </div>
            </motion.div>
          )}

          {activeTab === 'my-subscriptions' && (
            <MySubscriptionsView
              subscriptions={subscriptions}
              filteredSubscriptions={filteredSubscriptions}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              handleSort={handleSort}
              deleteSubscription={deleteSubscription}
            />
          )}

          {activeTab === 'pending-approval' && currentUser.role === UserRole.ADMIN && (
            <PendingApprovalView
              subscriptions={subscriptions}
              updateStatus={updateStatus}
            />
          )}

          {activeTab === 'renewals' && (
            <RenewalsView
              subscriptions={subscriptions}
              updateStatus={updateStatus}
              userRole={currentUser.role}
              onNavigateToNew={() => setActiveTab('new')}
            />
          )}

          {activeTab === 'payments' && currentUser.role === UserRole.ADMIN && (
            <PaymentsView
              subscriptions={subscriptions}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              updateStatus={updateStatus}
            />
          )}

          {activeTab === 'post-copy' && (
            <PostCopyView
              filteredSubscriptions={filteredSubscriptions}
              updateStatus={updateStatus}
            />
          )}

          {activeTab === 'user-management' && currentUser.role === UserRole.ADMIN && (
            <UserManagementView users={users} onAddUser={addUser} onDeleteUser={deleteUser} />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
