import { Subscription, SubscriptionStatus, Frequency } from '../types';

const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbx7DwnUDIJrtc2WSurm7N5Y1oef1Y8r21kt6H-IMzHQJlKExZzqm5pvgprOQTTQ7CvD6w/exec";

// Normalize any date string into consistent "M/D/YYYY H:MM:SS" format matching the Google Sheet
// e.g. "3/6/2026 16:27:37"
const normalizeDate = (val: any): string => {
  if (!val) return '';
  const s = val.toString().trim();
  if (!s) return '';
  const d = new Date(s);
  if (isNaN(d.getTime())) return s; // can't parse — return as-is
  const M = d.getMonth() + 1;
  const D = d.getDate();
  const Y = d.getFullYear();
  const h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, '0');
  const sec = d.getSeconds().toString().padStart(2, '0');
  return `${M}/${D}/${Y} ${h}:${m}:${sec}`;
};

const GOOGLE_FORM_URL = 'https://script.google.com/macros/s/AKfycbxFL1IqvhmiQVD9M_RdYUu9knaRkVFcQYayQ0Vyc6Dwb0r68mLvG6eeY44WlOhKJ7yNbQ/exec';

// Calculate delay in days between planned and actual dates
const calculateDelayDays = (planned: any, actual: any): string => {
  if (!planned || !actual) return "";
  const p = new Date(planned);
  const a = new Date(actual);
  if (isNaN(p.getTime()) || isNaN(a.getTime())) return "";

  // Normalize to start of day for cleaner day difference
  p.setHours(0, 0, 0, 0);
  a.setHours(0, 0, 0, 0);

  const diffTime = a.getTime() - p.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return diffDays.toString();
};

// Returns date in "D-MMM-YYYY" format (e.g. "15-Feb-2026")
const formatSheetDate = (val: any): string => {
  if (!val) return "";
  const d = new Date(val);
  if (isNaN(d.getTime())) return val.toString();

  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const day = d.getDate();
  const month = months[d.getMonth()];
  const year = d.getFullYear();

  return `${day}-${month}-${year}`;
};

export const fetchFromSheet = async (): Promise<Subscription[] | null> => {
  try {
    console.log("Fetching from sheet:", SCRIPT_URL);
    const response = await fetch(`${SCRIPT_URL}?sheetName=FMS`);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      const text = await response.text();
      console.error("Expected JSON but got:", text.substring(0, 100));
      throw new Error("Received non-JSON response from Google Sheets");
    }

    const data = await response.json();
    console.log("Data received from sheet:", data);

    let rows: any[] = [];
    if (Array.isArray(data)) {
      // Find the header row (the one that contains "Subscription No" or "Timestamp" or "Subscriber")
      let headerRowIndex = -1;
      for (let i = 0; i < data.length; i++) {
        const row = data[i];
        if (Array.isArray(row) && row.some(cell => {
          const s = cell.toString().toLowerCase();
          return s.includes("subscription no") ||
            s.includes("timestamp") ||
            s.includes("subscriber") ||
            s.includes("sub no") ||
            s.includes("name of the perosn");
        })) {
          headerRowIndex = i;
          break;
        }
      }

      // Find the group header row (look for "Approval For Subscription")
      let groupRowIndex = -1;
      for (let i = 0; i < Math.max(0, headerRowIndex); i++) {
        if (data[i].some(c => c.toString().toLowerCase().includes("approval for subscription"))) {
          groupRowIndex = i;
          break;
        }
      }
      const groupHeaders = groupRowIndex !== -1 ? data[groupRowIndex] : [];

      if (headerRowIndex !== -1 && Array.isArray(data[headerRowIndex])) {
        const rawHeaders = data[headerRowIndex];
        const headers = rawHeaders.map((h: any, i: number) => {
          const cleanH = h.toString().toLowerCase().replace(/[^a-z0-9]/g, '');
          if (!cleanH) return `col${i}`;

          // Find which group this column belongs to
          let group = "";
          for (let j = i; j >= 0; j--) {
            if (groupHeaders[j] && groupHeaders[j].toString().trim() !== "") {
              group = groupHeaders[j].toString().toLowerCase().replace(/[^a-z0-9]/g, '');
              break;
            }
          }

          if (group.includes("approval")) return `approval_${cleanH}`;
          if (group.includes("payment")) return `payment_${cleanH}`;
          if (group.includes("renewal")) return `renewal_${cleanH}`;
          return cleanH;
        });

        rows = data.slice(headerRowIndex + 1).map((row: any[], rowIndex: number) => {
          const obj: any = {};
          if (Array.isArray(row)) {
            row.forEach((val, i) => {
              const header = headers[i];
              obj[header] = val;
              obj[`raw_col_${i}`] = val; // Backup mapping
            });
          }
          return obj;
        });
      } else if (data.length > 0 && Array.isArray(data[0])) {
        // Fallback to first row if no header found
        const rawHeaders = data[0];
        const headers = rawHeaders.map((h: any) => h.toString().toLowerCase().replace(/[^a-z0-9]/g, ''));
        rows = data.slice(1).map((row: any[]) => {
          const obj: any = {};
          if (Array.isArray(row)) {
            row.forEach((val, i) => {
              const header = headers[i] || `col${i}`;
              obj[header] = val;
              obj[`raw_col_${i}`] = val;
            });
          }
          return obj;
        });
      }
    }

    if (rows.length > 0) {
      return rows
        .filter((item: any) => {
          // Must have at least some non-empty values
          const hasData = Object.values(item).some(val => val !== "" && val !== null && val !== undefined);
          if (!hasData) return false;

          // Must have a real subscription number (starts with SUB-) OR
          // at least 3 non-empty meaningful fields (to exclude rows that only have a Status value)
          const vals = Object.entries(item)
            .filter(([k]) => !k.startsWith('raw_col_'))
            .map(([, v]) => v)
            .filter(v => v !== "" && v !== null && v !== undefined);
          const hasSubNo = vals.some(v => v && v.toString().toUpperCase().startsWith('SUB-'));
          const hasMeaningfulData = vals.length >= 3; // at least 3 non-empty columns
          return hasSubNo || hasMeaningfulData;
        })
        .map((item: any, index: number) => {
          const getVal = (keys: string[], colIndex: number, fallback: any = "") => {
            const clean = (s: any) => s ? s.toString().toLowerCase().replace(/[^a-z0-9]/g, '') : '';
            const itemKeys = Object.keys(item);

            // 1. Try by cleaned header names (Most flexible)
            for (const searchKey of keys) {
              const target = clean(searchKey);
              const foundKey = itemKeys.find(k => clean(k) === target || clean(k).includes(target));
              if (foundKey && item[foundKey] !== "" && item[foundKey] !== null && item[foundKey] !== undefined) {
                return item[foundKey];
              }
            }

            // 2. Try by column index backup (Reliable if headers are missing/unclear)
            const backupKey = `raw_col_${colIndex}`;
            if (item[backupKey] !== undefined && item[backupKey] !== "" && item[backupKey] !== null) {
              return item[backupKey];
            }

            return fallback;
          };

          // Mapping based on your sheet screenshot:
          // A(0):Timestamp, B(1):SubNo, C(2):Name Of The Perosn, D(3):SubName, E(4):Purpose, F(5):Price, G(6):Freq, H(7):Status, I(8):Planned, J(9):Actual, K(10):Status, L(11):Photo

          // SELF-HEALING: If Column A contains a Subscription ID instead of a Date, swap them
          let rawCreatedAt = getVal(["timestamp", "time"], 0, new Date().toISOString());
          let rawSubNo = getVal(["subscriptionno", "subno", "no"], 1, `SUB-${(index + 1).toString().padStart(4, '0')}`);

          if (rawCreatedAt && rawCreatedAt.toString().startsWith("SUB-")) {
            const temp = rawCreatedAt;
            rawCreatedAt = rawSubNo;
            rawSubNo = temp;
          }

          const rawStatus = getVal(["status", "approval", "approvalforsubscriptionstatus"], 7, SubscriptionStatus.PENDING_APPROVAL);
          let status = SubscriptionStatus.PENDING_APPROVAL;
          const cleanStatus = rawStatus.toString().toUpperCase().replace(/[^A-Z]/g, '');

          if (cleanStatus.includes('ACTIVE')) status = SubscriptionStatus.ACTIVE;
          else if (cleanStatus.includes('PAYMENT') || cleanStatus.includes('APPROVED')) status = SubscriptionStatus.PENDING_PAYMENT;
          else if (cleanStatus.includes('PAID')) status = SubscriptionStatus.PAID;
          else if (cleanStatus.includes('REJECTED')) status = SubscriptionStatus.REJECTED;
          else if (cleanStatus.includes('EXPIRED')) status = SubscriptionStatus.EXPIRED;
          else if (cleanStatus === 'PENDING') status = SubscriptionStatus.PENDING_APPROVAL; // Exact match for "Pending"

          const getValWithStatus = (keys: string[], colIndex: number, fallback: any = "") => {
            const clean = (s: any) => s ? s.toString().toLowerCase().replace(/[^a-z0-9]/g, '') : '';
            const itemKeys = Object.keys(item);

            // Determine prefix based on status
            let prefix = "approval_";
            if (status === SubscriptionStatus.PENDING_PAYMENT) prefix = "payment_";
            if (status === SubscriptionStatus.ACTIVE || status === SubscriptionStatus.PAID) prefix = "renewal_";

            for (const searchKey of keys) {
              const target = clean(searchKey);
              // 1. Try with prefix first (Status-aware)
              const prefKey = `${prefix}${target}`;
              if (item[prefKey] !== undefined && item[prefKey] !== "" && item[prefKey] !== null) {
                return item[prefKey];
              }
              // 2. Try original (Fallback)
              const foundKey = itemKeys.find(k => clean(k) === target);
              if (foundKey && item[foundKey] !== "" && item[foundKey] !== null) {
                return item[foundKey];
              }
            }

            // 3. Try by column index backup
            const backupKey = `raw_col_${colIndex}`;
            if (item[backupKey] !== undefined && item[backupKey] !== "" && item[backupKey] !== null) {
              return item[backupKey];
            }
            return fallback;
          };

          // For Approved On, we specifically look for the "Actual" column in the "Approval" section
          // as that is where the review date is stored in this specific sheet layout.
          let approvedOnVal = item["approval_actual"] || item["approval_approvedon"] || item["approval_reviewedon"] || "";

          if (!approvedOnVal) {
            approvedOnVal = getValWithStatus(["approvedon", "approvedat", "reviewedon", "reviewedat", "approved", "reviewed", "approvaldate"], 12, "");
          }

          if (approvedOnVal.toString().toUpperCase().replace(/[^A-Z]/g, '') === cleanStatus) {
            approvedOnVal = "";
          }

          return {
            id: item.id || `sheet-${index}`,
            rowIndex: index,
            subscriptionNo: rawSubNo,
            companyName: getVal(["companyname", "company", "nameofthecompany"], 12, "Unknown"),
            subscriberName: getVal(["subscribername", "subscriber", "person", "nameoftheperosn", "nameoftheperson", "name"], 2, "Unknown"),
            subscriptionName: getVal(["subscriptionname", "subscription", "subname"], 3, "Unknown"),
            details: getVal(["details", "purpose", "purposeofsubscription"], 4, ""),
            price: parseFloat(getVal(["price", "cost", "amount"], 5, "0").toString().replace(/[^0-9.]/g, '')) || 0,
            frequency: getVal(["frequency", "freq"], 6, Frequency.MONTHLY) as Frequency,
            status,
            startDate: normalizeDate(getValWithStatus(["startdate", "planned", "plannedstart"], 8, "")),
            endDate: normalizeDate(getValWithStatus(["enddate", "actual", "actualend"], 9, "")),
            approvedOn: normalizeDate(approvedOnVal),
            timeDelay: getValWithStatus(["timedelay", "delay"], 13, ""),
            photoUrl: getValWithStatus(["photourl", "photo", "image", "photourl"], 11, ""),
            createdAt: normalizeDate(rawCreatedAt)
          };
        });
    }
    console.warn("Received data is empty or invalid format:", data);
    return [];
  } catch (error: any) {
    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      console.error("Error fetching from sheet: Network error or CORS issue. This usually means the Google Apps Script is not deployed to 'Anyone' or the URL is incorrect.");
    } else {
      console.error("Error fetching from sheet:", error);
    }
    return null;
  }
};

export const addSubscriptionToSheet = async (sub: Subscription) => {
  try {
    const ts = normalizeDate(new Date());
    const payload = {
      sheetName: "FMS",
      action: "ADD",
      // camelCase keys
      timestamp: ts,
      subscriptionNo: sub.subscriptionNo,
      subscriberName: sub.subscriberName,
      subscriptionName: sub.subscriptionName,
      details: sub.details,
      price: sub.price,
      frequency: sub.frequency,
      status: "Pending",
      startDate: sub.startDate || "",
      endDate: sub.endDate || "",
      companyName: sub.companyName,

      // Header-friendly names for the Apps Script
      "Timestamp": ts,
      "Subscription No": sub.subscriptionNo,
      "Subscription No.": sub.subscriptionNo,
      "Name Of The Perosn": sub.subscriberName,   // intentional typo matching sheet header
      "Name Of The Person": sub.subscriberName,
      "Subscription Name": sub.subscriptionName,
      "Purpose Of Subscription": sub.details,
      "Price": sub.price,
      "Frequency": sub.frequency,
      "Status": "Pending",
      "Planned": normalizeDate(sub.startDate) || "",
      "Actual": normalizeDate(sub.endDate) || "",
      "Company": sub.companyName,
      "Company Name": sub.companyName,
    };

    console.log("Adding subscription to sheet:", payload);

    await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify(payload),
      mode: "no-cors",
    });

    // Also write to Subscription's sheet
    await addToSubscriptionLogSheet(sub);

    return true;
  } catch (error) {
    console.error("Error posting to web app:", error);
    return false;
  }
};

export const updateSubscriptionInSheet = async (sub: Subscription) => {
  try {
    // Map status to a human-readable value the sheet can store and re-read correctly
    const statusMap: Record<string, string> = {
      'PENDING_APPROVAL': 'Pending',
      'APPROVED': 'Approved',
      'PENDING_PAYMENT': 'Approved',   // sheet reads "APPROVED" → PENDING_PAYMENT
      'PAID': 'Paid',
      'ACTIVE': 'Active',
      'REJECTED': 'Rejected',
      'EXPIRED': 'Expired',
    };
    const sheetStatus = statusMap[sub.status] ?? sub.status;

    const payload = {
      sheetName: "FMS",
      action: "UPDATE",

      // Row position — most reliable way for the Apps Script to find the right row
      // (rowIndex is 0-based from data rows; rowNumber is 1-based from data rows)
      rowIndex: sub.rowIndex ?? -1,
      rowNumber: sub.rowIndex !== undefined ? sub.rowIndex + 1 : -1,

      // Key used by Apps Script to find the row — send every possible variant
      subscriptionNo: sub.subscriptionNo,
      "Subscription No": sub.subscriptionNo,
      "Subscription No.": sub.subscriptionNo,
      "Sub No": sub.subscriptionNo,

      // Status — human-readable form the sheet understands
      status: sheetStatus,
      "Status": sheetStatus,

      // Full subscription data (so the script can update any column it knows about)
      subscriberName: sub.subscriberName,
      "Name Of The Perosn": sub.subscriberName,    // intentional typo matching sheet header
      "Name Of The Person": sub.subscriberName,
      subscriptionName: sub.subscriptionName,
      "Subscription Name": sub.subscriptionName,
      details: sub.details,
      "Purpose Of Subscription": sub.details,
      price: sub.price,
      "Price": sub.price,
      frequency: sub.frequency,
      "Frequency": sub.frequency,
      companyName: sub.companyName,
      "Company Name": sub.companyName,
      "Company": sub.companyName,

      // Dates — normalize to consistent format
      startDate: normalizeDate(sub.startDate) || "",
      endDate: normalizeDate(sub.endDate) || "",
      "Start Date": normalizeDate(sub.startDate) || "",
      "End Date": normalizeDate(sub.endDate) || "",
      "Planned": normalizeDate(sub.startDate) || "",
      "Actual": normalizeDate(sub.endDate) || "",

      // Renewal dates in specific "D-MMM-YYYY" format as requested
      "Renewal Planned": formatSheetDate(sub.startDate) || "",
      "Renewal Actual": formatSheetDate(sub.endDate) || "",

      // Approval date
      approvedOn: normalizeDate(sub.approvedOn) || "",
      "Approved On": normalizeDate(sub.approvedOn) || "",
      "Approved At": normalizeDate(sub.approvedOn) || "",
      "Reviewed On": normalizeDate(sub.approvedOn) || "",
      "Reviewed At": normalizeDate(sub.approvedOn) || "",
      "Approval Actual": normalizeDate(sub.approvedOn) || "",

      // Photo
      photoUrl: sub.photoUrl || "",
      "Photo Url": sub.photoUrl || "",
      "Photo URL": sub.photoUrl || "",
      "Photo": sub.photoUrl || "",

      // Time Delay
      "Time Delay": calculateDelayDays(sub.startDate, sub.endDate),
      "Payment Time Delay": statusMap[sub.status] === 'Approved' ? calculateDelayDays(sub.startDate, sub.endDate) : "",
      "Renewal Time Delay": statusMap[sub.status] === 'Active' ? calculateDelayDays(sub.startDate, sub.endDate) : "",
    };

    console.log("Updating subscription in sheet:", sub.subscriptionNo, "status →", sheetStatus, payload);

    await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify(payload),
      mode: "no-cors",
    });
    return true;
  } catch (error) {
    console.error("Error updating sheet:", error);
    return false;
  }
};

export const deleteSubscriptionFromSheet = async (subscriptionNo: string) => {
  try {
    await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify({
        action: "DELETE",
        sheetName: "FMS",
        subscriptionNo: subscriptionNo
      }),
      mode: "no-cors",
    });
    return true;
  } catch (error) {
    console.error("Error deleting from sheet:", error);
    return false;
  }
};

// Write a renewal entry to the "Renewal DB" sheet
// Headers: Subscription No. | Name Of The Perosn | Subscription Name | Purpose Of Subscription | Price | Freq | Planned | Step | Gmail ID | How | Renwal Form | Query | Step
export const addToRenewalDB = async (sub: Subscription) => {
  const plannedDate = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

  const payload: Record<string, any> = {
    sheetName: "Renewal DB",
    action: "ADD",
    subscriptionNo: sub.subscriptionNo,
    "Subscription No.": sub.subscriptionNo,
    "Subscription No": sub.subscriptionNo,
    "Name Of The Perosn": sub.subscriberName,
    "Name Of The Person": sub.subscriberName,
    "Subscription Name": sub.subscriptionName,
    "Purpose Of Subscription": sub.details,
    "Price": sub.price,
    "Price ": sub.price,
    "Freq": sub.frequency,
    "Planned": plannedDate,
    "Step": "",
    "Gmail ID": "",
    "How": GOOGLE_FORM_URL,
    "Renwal Form": "",
    "Query": "",
  };

  console.log("▶ addToRenewalDB →", sub.subscriptionNo);
  try {
    await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify(payload),
      mode: "no-cors",
    });
    console.log("✅ Renewal DB write sent for:", sub.subscriptionNo);
    return true;
  } catch (err) {
    console.error("❌ Renewal DB write failed:", err);
    return false;
  }
};

// Write a log entry to the "Subscription's" sheet
export const addToSubscriptionLogSheet = async (sub: Subscription) => {
  const ts = normalizeDate(new Date());

  const payload: Record<string, any> = {
    sheetName: "Subscription's",
    action: "ADD",
    "Timestamp": ts,
    "Subscription No.": sub.subscriptionNo,
    "Subscription No": sub.subscriptionNo,
    "Subscription Name": sub.subscriptionName,
    "Price": sub.price,
    "Frequency": sub.frequency,
    "Start Date": sub.startDate || "",
    "End Date": sub.endDate || ""
  };

  console.log("▶ addToSubscriptionLogSheet →", sub.subscriptionNo);
  try {
    await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify(payload),
      mode: "no-cors",
    });
    console.log("✅ Subscription's sheet write sent for:", sub.subscriptionNo);
    return true;
  } catch (err) {
    console.error("❌ Subscription's sheet write failed:", err);
    return false;
  }
};


export const fetchUsersFromSheet = async (): Promise<any[] | null> => {
  try {
    const response = await fetch(`${SCRIPT_URL}?sheetName=Login`);
    if (!response.ok) return null;
    const data = await response.json();
    console.log("Raw Users Data from Sheet (Login):", data);

    if (Array.isArray(data) && data.length > 0) {
      const rawHeaders = data[0];
      const headers = rawHeaders.map((h: any) => h.toString().toLowerCase().trim().replace(/[^a-z0-9]/g, ''));

      return data.slice(1).map((row: any[]) => {
        const obj: any = {};
        row.forEach((val, i) => {
          const key = headers[i] || `col${i}`;
          obj[key] = val !== null && val !== undefined ? val.toString().trim() : '';
        });
        return obj;
      });
    }
    return [];
  } catch (error) {
    console.error("Error fetching users:", error);
    return null;
  }
};

export const addUserToSheet = async (user: any) => {
  try {
    await fetch(SCRIPT_URL, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify({
        action: "ADD",
        sheetName: "Login",
        username: user.username,
        name: user.name,
        email: user.email,
        password: user.password,
        role: user.role,
        "Username": user.username,
        "Name": user.name,
        "Email": user.email,
        "Password": user.password,
        "Role": user.role
      })
    });
    return true;
  } catch (error) {
    console.error("Error adding user to sheet:", error);
    return false;
  }
};

export const deleteUserFromSheet = async (username: string) => {
  try {
    await fetch(SCRIPT_URL, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify({
        action: "DELETE",
        sheetName: "Login",
        username: username
      })
    });
    return true;
  } catch (error) {
    console.error("Error deleting user from sheet:", error);
    return false;
  }
};
